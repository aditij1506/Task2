import React from 'react'
import './Style.css'
const Home = () => {
    return (
        <div>
            <div className="home">
                <h1><span>W</span>elcome to the world <br /> of LetsGrowMore!</h1>
            </div>
        </div>
    )
}

export default Home;
