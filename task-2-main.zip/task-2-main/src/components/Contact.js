import React from 'react'
import './Style.css'
const Contact = () => {
    return (
        <div>
           <div className='contact'>
                <h1>Contact </h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere <br/><br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod? <br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem,  quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod? <br/><br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, </p>
                
            </div>
        </div>
    )
}

export default Contact;
